# Hackathon FastAPI Starter

A ready-to-use FastAPI backend with auth, database, and CRUD — clone and go.

## Quickstart

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/fastapi-starter.git
cd fastapi-starter

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up environment
cp .env.example .env

# 4. Run
uvicorn app.main:app --reload
```

API docs available at: http://localhost:8000/docs

## Structure

```
app/
├── main.py           # App entry point, CORS, routers
├── core/
│   ├── config.py     # Settings from .env
│   └── security.py   # JWT auth, password hashing
├── db/
│   └── database.py   # SQLAlchemy engine + get_db dependency
├── models/
│   ├── user.py       # User table
│   └── item.py       # Item table (rename for your use case)
├── schemas/
│   ├── user.py       # Pydantic schemas for User
│   └── item.py       # Pydantic schemas for Item
└── routers/
    ├── auth.py       # POST /auth/register, POST /auth/login
    ├── users.py      # GET /users/me, GET /users/{id}
    └── items.py      # Full CRUD /items
```

## Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| POST | /auth/register | No | Create account |
| POST | /auth/login | No | Get JWT token |
| GET | /users/me | Yes | Current user |
| GET | /items/ | Yes | List my items |
| POST | /items/ | Yes | Create item |
| PUT | /items/{id} | Yes | Update item |
| DELETE | /items/{id} | Yes | Delete item |

## Adapting for your hackathon

1. Rename `Item` model to whatever your domain needs (e.g. `Report`, `Post`, `Booking`)
2. Add fields to the model and schema
3. Add a new router file and register it in `main.py`
4. Done
